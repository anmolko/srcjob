    <div class="service-details__sidebar">
        <div class="service-details__sidebar-single service-details__service-list-box">
            <h3 class="service-details__service-title">Services List</h3>
            <ul class="service-details__service-list list-unstyled">

            <?php if(!empty($latestServices)): ?>
                <?php $__currentLoopData = $latestServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php if(Request::url() === url('/service/'.$latest->slug)): ?> active <?php endif; ?> "><a   href="<?php echo e(route('service.single',$latest->slug)); ?>"><?php echo e(ucwords(@$latest->title)); ?><span
                            class="icon-right-arrow1"></span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
               
            </ul>
        </div>
        
        <div class="service-details__sidebar-single sidebar__call-box">
            <div class="sidebar__call-bg"
                style="background-image: url(<?php echo e(asset('assets/frontend/images/backgrounds/sidebar-call-bg.jpg')); ?>);"></div>
            <div class="sideber__call-content">
                <h3 class="sideber__call-title">Want to  <br> Get in touch <br> with us                </h3>
                <div class="sideber__call-number">
                    <p>feel free to call</p>
                    <h3><a href="tel:<?php if(!empty(@$setting_data->phone)): ?> <?php echo e(@$setting_data->phone); ?> <?php else: ?> +9771238798 <?php endif; ?>"><?php if(!empty(@$setting_data->phone)): ?> <?php echo e(@$setting_data->phone); ?> <?php else: ?> +9771238798 <?php endif; ?></a></h3>
                </div>
                <div class="sideber__call-button">
                    <div class="sideber__call-button-shape"></div>
                    <a href="#"><i class="icon-right-arrow1"></i>Sent us a message</a>
                </div>
            </div>
        </div>
    </div><?php /**PATH D:\project\srcjob\resources\views/frontend/pages/services/sidebar.blade.php ENDPATH**/ ?>