
<?php $__env->startSection('title'); ?> Home <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    @media only screen and (min-width:768px){
        .counter-item.style-two {
            height: 400px;
        }

        .feature-item-four {
            height: 215px;
        }
    }

    .author.post-category i {
        font-size: 40px;
        margin-right: 15px;
    }

    .icon-different {
        color: white;
        font-size: 65px;
        -webkit-transition: 0.5s;
        -o-transition: 0.5s;
        transition: 0.5s;
        display: inline-block;
        width: 120px;
        height: 120px;
        background: #fc653c;
        line-height: 120px;
        border-radius: 50%;
        text-align: center;
    }

    section.newsletter-one.about-status {
        margin-bottom: 50px;
        margin-top: 50px;
        z-index: unset;
    }

    .about-status .newsletter-one__inner{
        padding-bottom: 36px;
        justify-content: center;
    }

    .about-status .newsletter-one__inner .cta-one__right-count{
        margin-bottom: 0px;
        text-align: center;
    }

    .newsletter-one__left > div {
        margin-right: 50px;
        margin-left: 20px;
    }

    .about-status p.cta-one__right-text {
        margin-top: 5px;
    }

    .blog-three {
        margin-top: 50px;
    }

    .join-us__text-one {
        margin-bottom: 40px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(count($sliders) > 0): ?>
        <!--Main Slider Start-->
        <section class="main-slider clearfix">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5000
                }}'>
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = @$sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="image-layer"
                                style="background-image: url(<?php echo e(asset('/images/sliders/'.$slider->image)); ?>);"></div>
                            <!-- /.image-layer -->
                            <div class="main-slider-overly-one"></div>
                            <div class="main-slider-overly-two"></div>
                            <div class="main-slider-shape-1 float-bob-x">
                                <img src="<?php echo e(asset('assets/frontend/images/shapes/main-slider-shape-1.png')); ?>" alt="">
                            </div>
                            <div class="main-slider-shape-2 float-bob-y">
                                <img src="<?php echo e(asset('assets/frontend/images/shapes/main-slider-shape-2.png')); ?>" alt="">
                            </div>
                            <div class="main-slider-shape-3 float-bob-y">
                                <img src="<?php echo e(asset('assets/frontend/images/shapes/main-slider-shape-3.png')); ?>" alt="">
                            </div>

                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-10">
                                        <div class="main-slider__content">
                                            <?php if(@$slider->slider_link): ?>
                                                <div class="main-slider__video-link">
                                                    <a href="<?php echo e(@$slider->slider_link); ?>" class="video-popup">
                                                        <div class="main-slider__video-icon">
                                                            <span class="fa fa-play"></span>
                                                            <i class="ripple"></i>
                                                        </div>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            <p class="main-slider__sub-title"><?php echo e(@$slider->subheading); ?></p>
                                            <h2 class="main-slider__title"><?php echo e(@$slider->heading); ?></h2>
                                            <div class="main-slider__btn-box">
                                            <?php if(@$slider->button): ?>
                                                <a href="<?php echo e(@$slider->link); ?>" class="thm-btn main-slider__btn"><?php echo e(@$slider->button); ?></a>
                                            <?php endif; ?>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-up-arrow"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-up-arrow"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--Main Slider End-->

    <?php endif; ?>


    <?php if(!empty($homepage_info->welcome_description)): ?>
        <!-- Welcome section -->
        <section class="join-us">
            <div class="container">
                <div class="row">
                    <?php if(@$homepage_info->welcome_side_image == "left"): ?> 

                        <div class="col-xl-5 col-lg-5">
                            <div class="join-us__left">
                                <div class="join-us__img-box wow slideInLeft" data-wow-delay="100ms"
                                    data-wow-duration="2500ms">
                                    <div class="join-us__img">
                                        <img src="<?php if(!empty(@$homepage_info->welcome_image)){ echo '/images/home/welcome/'.@$homepage_info->welcome_image; } ?>" alt="About us">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7">
                            <div class="join-us__right">
                                <div class="section-title text-left">
                                    <?php if(@$homepage_info->welcome_subheading): ?>
                                        <span class="section-title__tagline"><?php echo e(ucfirst(@$homepage_info->welcome_subheading)); ?></span>
                                    <?php endif; ?>
                                    <?php if(@$homepage_info->welcome_heading): ?>
                                        <h2 class="section-title__title"><span><?php echo e(ucwords(@$homepage_info->welcome_heading)); ?></span></h2>
                                    <?php endif; ?>
                            
                                </div>
                                <p class="join-us__text-one"><?php echo e(ucfirst(@$homepage_info->welcome_description)); ?></p>
                        
                                    <?php if(@$homepage_info->welcome_button): ?>
                                            <a href="<?php echo e(@$homepage_info->welcome_link); ?>" class="thm-btn join-us__right-btn"><?php echo e(ucwords(@$homepage_info->welcome_button)); ?> </a>
                                    <?php endif; ?>
                        
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-xl-7 col-lg-7">
                            <div class="join-us__right">
                                <div class="section-title text-left">
                                    <?php if(@$homepage_info->welcome_subheading): ?>
                                        <span class="section-title__tagline"><?php echo e(ucfirst(@$homepage_info->welcome_subheading)); ?></span>
                                    <?php endif; ?>
                                    <?php if(@$homepage_info->welcome_heading): ?>
                                        <h2 class="section-title__title"><span><?php echo e(ucwords(@$homepage_info->welcome_heading)); ?></span></h2>
                                    <?php endif; ?>
                            
                                </div>
                                <p class="join-us__text-one"><?php echo e(ucfirst(@$homepage_info->welcome_description)); ?></p>
                        
                                    <?php if(@$homepage_info->welcome_button): ?>
                                            <a href="<?php echo e(@$homepage_info->welcome_link); ?>" class="thm-btn join-us__right-btn"><?php echo e(ucwords(@$homepage_info->welcome_button)); ?> </a>
                                    <?php endif; ?>
                        
                            </div>
                        </div>
                        
                        <div class="col-xl-5 col-lg-5">
                            <div class="join-us__left">
                                <div class="join-us__img-box wow slideInLeft" data-wow-delay="100ms"
                                    data-wow-duration="2500ms">
                                    <div class="join-us__img">
                                        <img src="<?php if(!empty(@$homepage_info->welcome_image)){ echo '/images/home/welcome/'.@$homepage_info->welcome_image; } ?>" alt="About us">
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>

                </div>
            </div>
        </section>
        <!-- Welcome end -->
    <?php endif; ?>

        <!--Status-->
        <section class="newsletter-one about-status">
            <div class="container">
                <div class="newsletter-one__inner">
                    <div class="newsletter-one__left">
                       
                        <div class="cta-one__right-count">
                            <div class="cta-one__right-count-box">
                                <span class="fas fa-plane-departure cta-one__right-icon"></span>
                                <h3 class="odometer odometer-auto-theme" data-count="<?php echo e((@$homepage_info->project_completed) ? @$homepage_info->project_completed : '3670'); ?>">
                                    <div class="odometer-inside">
                                        <span class="odometer-digit">
                                            <span class="odometer-digit-spacer">8</span>
                                            <span class="odometer-digit-inner">
                                                
                                                <span class="odometer-ribbon">
                                                    <span class="odometer-ribbon-inner">
                                                        <span class="odometer-value">1</span>
                                                    </span>
                                                </span>
                                            </span>
                                        </span>
                                        <span class="odometer-digit"><span class="odometer-digit-spacer">8</span>
                                        <span class="odometer-digit-inner"><span class="odometer-ribbon">
                                            <span class="odometer-ribbon-inner"><span class="odometer-value">7</span></span></span>
                                        </span></span>
                                    </div>
                                </h3>
                                <span class="cta-one__right-expert-plus">+</span>
                            </div>
                            <p class="cta-one__right-text">Projects Completed</p>
                        </div>
                        
                        <div class="cta-one__right-count">
                            <div class="cta-one__right-count-box">
                                <span class="fas fa-user-check cta-one__right-icon"></span>
                                <h3 class="odometer odometer-auto-theme" data-count="<?php echo e((@$homepage_info->visa_approved) ? @$homepage_info->visa_approved : '3670'); ?>">
                                    <div class="odometer-inside">
                                        <span class="odometer-digit">
                                            <span class="odometer-digit-spacer">8</span>
                                            <span class="odometer-digit-inner">
                                                
                                                <span class="odometer-ribbon">
                                                    <span class="odometer-ribbon-inner">
                                                        <span class="odometer-value">1</span>
                                                    </span>
                                                </span>
                                            </span>
                                        </span>
                                        <span class="odometer-digit"><span class="odometer-digit-spacer">8</span>
                                        <span class="odometer-digit-inner"><span class="odometer-ribbon">
                                            <span class="odometer-ribbon-inner"><span class="odometer-value">7</span></span></span>
                                        </span></span>
                                    </div>
                                </h3>
                                <span class="cta-one__right-expert-plus">+</span>
                            </div>
                            <p class="cta-one__right-text">Visa Approved</p>
                        </div>

                        <div class="cta-one__right-count">
                            <div class="cta-one__right-count-box">
                                <span class="far fa-smile cta-one__right-icon"></span>
                                <h3 class="odometer odometer-auto-theme" data-count="<?php echo e((@$homepage_info->happy_clients) ? @$homepage_info->happy_clients : '3670'); ?>">
                                    <div class="odometer-inside">
                                        <span class="odometer-digit">
                                            <span class="odometer-digit-spacer">8</span>
                                            <span class="odometer-digit-inner">
                                                
                                                <span class="odometer-ribbon">
                                                    <span class="odometer-ribbon-inner">
                                                        <span class="odometer-value">1</span>
                                                    </span>
                                                </span>
                                            </span>
                                        </span>
                                        <span class="odometer-digit"><span class="odometer-digit-spacer">8</span>
                                        <span class="odometer-digit-inner"><span class="odometer-ribbon">
                                            <span class="odometer-ribbon-inner"><span class="odometer-value">7</span></span></span>
                                        </span></span>
                                    </div>
                                </h3>
                                <span class="cta-one__right-expert-plus">+</span>
                            </div>
                            <p class="cta-one__right-text">Happy Clients</p>
                        </div>

                        <div class="cta-one__right-count">
                            <div class="cta-one__right-count-box">
                                <span class="fas fa-thumbs-up cta-one__right-icon"></span>
                                <h3 class="odometer odometer-auto-theme" data-count="<?php echo e((@$homepage_info->success_stories) ? @$homepage_info->success_stories : '3670'); ?>">
                                    <div class="odometer-inside">
                                        <span class="odometer-digit">
                                            <span class="odometer-digit-spacer">8</span>
                                            <span class="odometer-digit-inner">
                                                
                                                <span class="odometer-ribbon">
                                                    <span class="odometer-ribbon-inner">
                                                        <span class="odometer-value">1</span>
                                                    </span>
                                                </span>
                                            </span>
                                        </span>
                                        <span class="odometer-digit"><span class="odometer-digit-spacer">8</span>
                                        <span class="odometer-digit-inner"><span class="odometer-ribbon">
                                            <span class="odometer-ribbon-inner"><span class="odometer-value">7</span></span></span>
                                        </span></span>
                                    </div>
                                </h3>
                                <span class="cta-one__right-expert-plus">+</span>
                            </div>
                            <p class="cta-one__right-text">Success Stories</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!--Status-->
    <?php if(!empty($homepage_info->mv_heading)): ?>
        <!-- Mission Vision start -->
        <section class="testimonials-one">
            <div class="container">
                <div class="section-title text-center">
                  
                    <?php if(@$homepage_info->mv_subheading): ?>
                        <span class="section-title__tagline"><?php echo e(ucfirst(@$homepage_info->mv_subheading)); ?></span>
                    <?php endif; ?>
                    <?php if(@$homepage_info->mv_heading): ?>
                        <h2 class="section-title__title"><span><?php echo e(ucwords(@$homepage_info->mv_heading)); ?></span></h2>
                    <?php endif; ?>
                </div>
                <div class="service-details__core-product-points-box">
                    <div class="row">
                        <div class="col-xl-4">
                            <div class="service-details__core-product-points-single">
                                <div class="service-details__core-product-icon-box">
                                    <div class="service-details__core-product-icon">
                                        <span class="icon-marketing-analysis-marketing-research"></span>
                                    </div>
                                    <div class="service-details__core-product-content">
                                        <h4>Mission</h4>
                                    </div>
                                </div>
                                <p class="service-details__core-product-text-2"><?php echo e(ucfirst(@$homepage_info->mission)); ?></p>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="service-details__core-product-points-single">
                                <div class="service-details__core-product-icon-box">
                                    <div class="service-details__core-product-icon">
                                        <span class="fas fa-eye"></span>
                                    </div>
                                    <div class="service-details__core-product-content">
                                        <h4>Vision</h4>
                                    </div>
                                </div>
                                <p class="service-details__core-product-text-2"><?php echo e(ucfirst(@$homepage_info->vision)); ?></p>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="service-details__core-product-points-single">
                                <div class="service-details__core-product-icon-box">
                                    <div class="service-details__core-product-icon">
                                        <span class="icon-protection-rain-umbrella"></span>
                                    </div>
                                    <div class="service-details__core-product-content">
                                        <h4>Value</h4>
                                    </div>
                                </div>
                                <p class="service-details__core-product-text-2"><?php echo e(ucfirst(@$homepage_info->value)); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
      
        <!-- Mission Vision end -->
    <?php endif; ?>

    <?php if(!empty($homepage_info->action_heading)): ?>
        <!-- CTA Area start -->
        <div class="cta-one">
            <div class="cta-one__bg-img" style="background-image: url(<?php echo e(asset('/assets/frontend/images/background/cta-one-bg-1.jpg')); ?>);">
            </div>
            <div class="container">
                <div class="cta-one__inner">
                    <div class="cta-one__left">
                        <div class="cta-one__content">
                            <h3 class="cta-one__title"><?php echo e(@$homepage_info->action_heading); ?></h3>
                        </div>
                    </div>
                    <div class="cta-one__right">
                        <div class="cta-one__right-button">
                            <a href="<?php echo e(@$homepage_info->action_link); ?>" class="thm-btn cta-one__right-btn">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     
        <!-- CTA Area end -->
    <?php endif; ?>

    <section class="about-one">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-one__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline"><?php echo e(ucwords(@$homepage_info->core_main_heading)); ?></span>
                                <h2 class="section-title__title"> <span><?php echo e(ucfirst(@$homepage_info->core_main_description)); ?></span></h2>
                            </div>
                            <ul class="about-one__points list-unstyled">
                                <li>
                                    <div class="icon">
                                        <span class="fas fa-handshake"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading1)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description1)); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="icon-analysis-analytics-business"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading2)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description2)); ?></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="about-one__right">
                            <ul class="about-one__points list-unstyled">
                                <li>
                                    <div class="icon">
                                        <span class="far fa-eye"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading3)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description3)); ?></p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fas fa-balance-scale"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading4)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description4)); ?></p>
                                    </div>
                                </li>
                                 <li>
                                    <div class="icon">
                                        <span class="fas fa-network-wired"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading5)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description5)); ?></p>
                                    </div>
                                </li>
                                 <li>
                                    <div class="icon">
                                        <span class="fas fa-user-shield"></span>
                                    </div>
                                    <div class="content">
                                        <h4><?php echo e(ucwords(@$homepage_info->core_heading6)); ?></h4>
                                        <p><?php echo e(ucfirst(@$homepage_info->core_description6)); ?></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php if(!empty($homepage_info->core_main_heading)): ?>

        <!-- Core value start -->
        <section class="feature-area-four pb-100 pt-200 rel z-1">
            <div class="container">
                <div class="section-title text-center mb-50 wow fadeInUp delay-0-2s">
                    <span class="sub-title style-two mb-15">Amazing  Features</span>
                    <h2><?php echo e(ucwords(@$homepage_info->core_main_heading)); ?></h2>
                    <p><?php echo e(ucfirst(@$homepage_info->core_main_description)); ?></p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-3s">
                            <h4><i class="fas fa-handshake"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading1)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description1)); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-5s">
                            <h4><i class="fas fa-file-contract"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading2)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description2)); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-7s">
                            <h4><i class="far fa-eye"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading3)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description3)); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-3s">
                            <h4><i class="fas fa-balance-scale"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading4)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description4)); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-5s">
                            <h4><i class="fas fa-chart-network"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading5)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description5)); ?></p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="feature-item-four wow fadeInUp delay-0-7s">
                            <h4><i class="fas fa-user-shield"></i><a href=""><?php echo e(ucwords(@$homepage_info->core_heading6)); ?></a></h4>
                            <p><?php echo e(ucfirst(@$homepage_info->core_description6)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Core value end -->
    <?php endif; ?>

    <?php if(count($latestServices) > 2): ?>
        <!-- Services start -->

        <section class="services-one">
              <div class="services-one__bg" style="background-image: url(assets/images/backgrounds/services-one-bg.jpg);">
              </div>
              <div class="container">
                  <div class="services-one__top text-center">
                      <div class="section-title">
                          <span class="section-title__tagline">Recent Services</span>
                          <h2 class="section-title__title"><span>Look at our latest services</span></h2>
                      </div>
                    
                  </div>

                  <div class="services-one__bottom">
                      <div class="services-one__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='{
                          "loop": true,
                          "autoplay": false,
                          "margin": 30,
                          "nav": false,
                          "dots": true,
                          "smartSpeed": 500,
                          "autoplayTimeout": 10000,
                          "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
                          "responsive": {
                              "0": {
                                  "items": 1
                              },
                              "768": {
                                  "items": 2
                              },
                              "992": {
                                  "items": 2
                              },
                              "1200": {
                                  "items": 3
                              }
                          }
                      }'>
                          <?php $__currentLoopData = @$latestServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <div class="item">
                              <div class="services-one__single">
                                  <div class="services-one__img">
                                      <img src="<?php if(@$service->banner_image){?><?php echo e(asset('/images/service/'.@$service->banner_image)); ?><?php }?>" alt="">
                                  </div>
                                  <div class="services-one__content">
                                     
                                      <h3 class="services-one__title"><a href="<?php echo e(route('service.single',$service->slug)); ?>"><?php echo e(ucwords(@$service->title)); ?></a></h3>
                                      <p class="services-one__text"><?php echo e(ucfirst(Str::limit(@$service->sub_description, 70,'...'))); ?></p>
                                      <div class="services-one__arrow">
                                          <a href="<?php echo e(route('service.single',$service->slug)); ?>"><i class="icon-right-arrow-1"></i></a>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                      </div>
                  </div>
              </div>
          </section>


        <!-- Services  end -->
    <?php endif; ?>




    <?php if(count($latestPosts) > 2): ?>

        <!--Blog One Start-->
        <section class="blog-three">
            <div class="container">
                <div class="section-title text-center">
                    <span class="section-title__tagline">Our Blog List</span>
                    <h2 class="section-title__title"><span>Latest Blog Post</span></h2>
                </div>
                <div class="row">
                    <?php $__currentLoopData = @$latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div class="blog-three__single">
                            <div class="blog-three__img">
                                <img src="<?php if(@$post->image){?><?php echo e(asset('/images/blog/'.@$post->image)); ?><?php }?>" alt="">
                            </div>
                            <div class="blog-three__content">
                                <div class="blog-three__date">
                                    <span><?php echo e(date('j',strtotime(@$post->created_at))); ?></span>
                                    <p><?php echo e(date('M',strtotime(@$post->created_at))); ?></p>
                                </div>
                                <div class="blog-three__title-box">
                                    
                                    <h4 class="blog-three__title"><a href="<?php echo e(route('blog.single',$post->slug)); ?>"><?php echo e(ucwords($post->title)); ?></a></h4>
                                </div>
                                <div class="blog-three__content-box">
                                    <ul class="blog-three__meta list-unstyled">
                                        <li>
                                            <a href="<?php echo e(url('/blog/categories/'.@$post->category->slug)); ?>"><i class="icon-tag-chevron-thin"></i><?php echo e(ucwords(@$post->category->name)); ?></a>
                                        </li>
                                       
                                    </ul>
                                    <div class="blog-three__btn-box">
                                        <a href="<?php echo e(route('blog.single',$post->slug)); ?>">Details<i
                                                class="icon-fast-forward-thin-double-arrows"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </section>
  
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\srcjob\resources\views/welcome.blade.php ENDPATH**/ ?>