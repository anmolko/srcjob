<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Src Job Placement"/>
		<link rel="canonical" href="https://srcjobplacement.com/" />
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

        <?php echo $__env->yieldContent('seo'); ?>

		<!-- FAVICON AND TOUCH ICONS -->

		<link rel="shortcut icon" type="image/x-icon" href="<?php if(@$setting_data->favicon){?><?php echo e(asset('/images/settings/'.@$setting_data->favicon)); ?><?php }?>">
 
     <!-- fonts -->
     <link rel="preconnect" href="https://fonts.googleapis.com/">

    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
        rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&amp;display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/animate/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/animate/custom-animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/fontawesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/jarallax/jarallax.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/jquery-magnific-popup/jquery.magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/nouislider/nouislider.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/nouislider/nouislider.pips.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/odometer/odometer.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/swiper/swiper.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/conalz-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/tiny-slider/tiny-slider.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/reey-font/stylesheet.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/owl-carousel/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/owl-carousel/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/bxslider/jquery.bxslider.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/bootstrap-select/css/bootstrap-select.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/vegas/vegas.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/jquery-ui/jquery-ui.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/timepicker/timePicker.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/polyglot-language-switcher/polyglot-language-switcher.css')); ?>" />
    <!-- template styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/conalz.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/conalz-responsive.css')); ?>" />
    <!-- Main Style -->

		 <!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(@$setting_data->google_analytics); ?>"></script>
		<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', '<?php echo e(@$setting_data->google_analytics); ?>');
		</script>
    <style>
      /* .main-menu .navbar-collapse li.active a {
          color: #fc653c;
      } */
    </style>
        <?php echo $__env->yieldContent('css'); ?>

	</head>
<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="page-wrapper">
        <header class="main-header clearfix">
            <div class="main-header__top">
                <div class="main-header__top-inner clearfix">
                    <div class="main-header__top-left">
                        <ul class="list-unstyled main-header__top-address-list">
                            <li>
                                <div class="icon">
                                    <span class="icon-email-1"></span>
                                </div>
                                <div class="text">
                                    <p><a href="mailto:<?php if(!empty(@$setting_data->email)): ?> <?php echo e(@$setting_data->email); ?> <?php else: ?> example@gmail.com <?php endif; ?>"><?php if(!empty(@$setting_data->email)): ?> <?php echo e(@$setting_data->email); ?> <?php else: ?> example@gmail.com <?php endif; ?></a></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span class="icon-clock"></span>
                                </div>
                                <div class="text">
                                    <p>Sun - Fri 9:00 am - 6:00 pm</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="main-header__top-right">
                        <div class="main-header__btn-box">
                            <a href="<?php echo e(route('contact')); ?>" class="thm-btn main-header__btn">Get Consulting</a>
                        </div>
                        <div class="main-header__top-social">
                        
                                <?php if(!empty(@$setting_data->facebook)): ?>
                                <a href="<?php if(!empty(@$setting_data->facebook)): ?> <?php echo e(@$setting_data->facebook); ?> <?php endif; ?>" target="_blank" class="social-fb"
                                ><i class="fab fa-facebook-f"></i
                                ></a>
                                <?php endif; ?>
                                <?php if(!empty(@$setting_data->youtube)): ?>

                                <a href="<?php if(!empty(@$setting_data->youtube)): ?> <?php echo e(@$setting_data->youtube); ?> <?php endif; ?>" target="_blank" class="social-youtube"
                                ><i class="fab fa-youtube"></i
                                ></a>
                                <?php endif; ?>
                                <?php if(!empty(@$setting_data->instagram)): ?>

                                <a href="<?php if(!empty(@$setting_data->instagram)): ?> <?php echo e(@$setting_data->instagram); ?> <?php endif; ?>" target="_blank" class="social-instagram"
                                ><i class="fab fa-instagram"></i
                                ></a>
                                <?php endif; ?>
                                <?php if(!empty(@$setting_data->linkedin)): ?>

                                <a href="<?php if(!empty(@$setting_data->linkedin)): ?> <?php echo e(@$setting_data->linkedin); ?> <?php endif; ?>" target="_blank" class="social-linkedin"
                                ><i class="fab fa-linkedin-in"></i
                                ></a>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="main-menu clearfix">
                <div class="main-menu__wrapper clearfix">
                    <div class="main-menu__wrapper-inner clearfix">
                        <div class="main-menu__left">
                            <div class="main-menu__logo">
                                    <?php if(request()->is('/')): ?>
                                        <a href="/"> <img src="<?php if(@$setting_data->logo){?><?php echo e(asset('/images/settings/'.@$setting_data->logo)); ?><?php }?>"  alt="Src Job Placement" title="Src Job Placement"></a>
                                    <?php endif; ?>
                            </div>
                            <div class="main-menu__main-menu-box">
                                <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                                <ul class="main-menu__list">
                                        <li class="<?php echo e(request()->is('/') ? 'current' : ''); ?> ">
                                        <a href="/" >Home</a>
                                        </li>

                                        <?php if(!empty($top_nav_data)): ?>
                                        <?php $__currentLoopData = $top_nav_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($nav->children[0])): ?>

                                                <li id="<?php echo e(@$loop->index); ?>" class="<?php echo e(request()->is(@$nav->slug)  ? 'current' : ''); ?> dropdown">
                                                    <a href="#" class=""><?php if(@$nav->name == NULL): ?> <?php echo e(ucwords(@$nav->title)); ?> <?php else: ?> <?php echo e(ucwords(@$nav->name)); ?> <?php endif; ?> </a>

                                                        <ul >
                                                        <?php $__currentLoopData = $nav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childNav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($childNav->type == 'custom'): ?>

                                                                <li  class="<?php echo e(request()->is(@$childNav->slug) ? 'current' : ''); ?> <?php if(!empty($childNav->children[0])): ?> dropdown <?php endif; ?> ">
                                                                    <a href="/<?php echo e(@$childNav->slug); ?>" class="" <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?> ><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
                                                                    <?php if(!empty($childNav->children[0])): ?>
                                                                        <ul >
                                                                            <?php $__currentLoopData = $childNav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lastchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($lastchild->type == 'custom'): ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                        <a href="/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?> ><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'post'): ?>
                                                                                    <li  class="<?php echo e(request()->is('blog/'.@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                        <a href="<?php echo e(url('blog')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'service'): ?>
                                                                                    <li  class="<?php echo e(request()->is('service/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('service')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php else: ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                            <a href="<?php echo e(url('/')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a>
                                                                                        </li>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php elseif($childNav->type == 'post'): ?>
                                                                <li  class="<?php echo e(request()->is('blog/'.@$childNav->slug) ? 'current' : ''); ?>  <?php if(!empty($childNav->children[0])): ?>  dropdown <?php endif; ?>">
                                                                    <a href="<?php echo e(url('blog')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
                                                                    <?php if(!empty($childNav->children[0])): ?>
                                                                        <ul >
                                                                            <?php $__currentLoopData = $childNav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lastchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($lastchild->type == 'custom'): ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                        <a href="/<?php echo e(@$childNav->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?> ><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'service'): ?>
                                                                                    <li  class="<?php echo e(request()->is('service/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('service')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'post'): ?>
                                                                                    <li  class="<?php echo e(request()->is('blog/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('blog')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php else: ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                            <a href="<?php echo e(url('/')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a>
                                                                                        </li>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php elseif($childNav->type == 'service'): ?>
                                                                <li  class="<?php echo e(request()->is('service/'.@$childNav->slug) ? 'current' : ''); ?>  <?php if(!empty($childNav->children[0])): ?>  dropdown <?php endif; ?>">
                                                                    <a href="<?php echo e(url('service')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
                                                                    <?php if(!empty($childNav->children[0])): ?>
                                                                        <ul >
                                                                            <?php $__currentLoopData = $childNav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lastchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($lastchild->type == 'custom'): ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                        <a href="/<?php echo e(@$childNav->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?> ><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'service'): ?>
                                                                                    <li  class="<?php echo e(request()->is('service/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('service')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'post'): ?>
                                                                                    <li  class="<?php echo e(request()->is('blog/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('blog')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php else: ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                            <a href="<?php echo e(url('/')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a>
                                                                                        </li>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php else: ?>
                                                                <li  class="<?php echo e(request()->is(@$childNav->slug) ? 'current' : ''); ?>  <?php if(!empty($childNav->children[0])): ?>  dropdown <?php endif; ?> ">
                                                                    <a href="<?php echo e(url('/')); ?>/<?php echo e(@$childNav->slug); ?>"  <?php if(@$childNav->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($childNav->name == NULL): ?> <?php echo e(@$childNav->title); ?> <?php else: ?> <?php echo e(@$childNav->name); ?> <?php endif; ?></a>
                                                                    <?php if(!empty($childNav->children[0])): ?>
                                                                        <ul >
                                                                            <?php $__currentLoopData = $childNav->children[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lastchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($lastchild->type == 'custom'): ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                        <a href="/<?php echo e(@$childNav->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?> ><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'service'): ?>
                                                                                    <li  class="<?php echo e(request()->is('service/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('service')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php elseif($lastchild->type == 'post'): ?>
                                                                                    <li  class="<?php echo e(request()->is('blog/'.@$lastchild->slug) ? 'current' : ''); ?>  ">
                                                                                        <a href="<?php echo e(url('blog')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if(@$lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a></li>
                                                                                <?php else: ?>
                                                                                    <li  class="<?php echo e(request()->is(@$lastchild->slug) ? 'current' : ''); ?> ">
                                                                                            <a href="<?php echo e(url('/')); ?>/<?php echo e(@$lastchild->slug); ?>"  <?php if(@$lastchild->target !== NULL): ?> target="_blank" <?php endif; ?>><?php if($lastchild->name == NULL): ?> <?php echo e(@$lastchild->title); ?> <?php else: ?> <?php echo e(@$lastchild->name); ?> <?php endif; ?></a>
                                                                                        </li>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    <?php endif; ?>

                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </ul>
                                                </li>

                                            <?php else: ?>
                                                <?php if($nav->type == 'custom'): ?>
                                                    <li   class="<?php echo e(request()->is(@$nav->slug.'*') ? 'current' : ''); ?> ">
                                                        <a href="/<?php echo e($nav->slug); ?>"  <?php if($nav->target == NULL): ?>  <?php else: ?> target="<?php echo e($nav->target); ?>" <?php endif; ?>><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a></li>
                                                <?php elseif($nav->type == 'service'): ?>
                                                    <li   class="<?php echo e(request()->is('service/'.@$nav->slug.'*') ? 'current' : ''); ?> ">
                                                        <a href="<?php echo e(url('service')); ?>/<?php echo e($nav->slug); ?>" ><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a></li>
                                                <?php elseif($nav->type == 'post'): ?>
                                                    <li   class="<?php echo e(request()->is('blog/'.@$nav->slug.'*') ? 'current' : ''); ?> ">
                                                        <a href="<?php echo e(url('blog')); ?>/<?php echo e($nav->slug); ?>" ><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a></li>
                                                <?php else: ?>
                                                    <li   class="<?php echo e(request()->is(@$nav->slug.'*') ? 'current' : ''); ?> ">
                                                        <a href="<?php echo e(url('/')); ?>/<?php echo e($nav->slug); ?>" ><?php if($nav->name == NULL): ?> <?php echo e($nav->title); ?> <?php else: ?> <?php echo e($nav->name); ?> <?php endif; ?></a></li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="main-menu__right">
                            <div class="main-menu__call-search">
                                <div class="main-menu__call">
                                    <div class="main-menu__call-icon">
                                        <span class="icon-phone"></span>
                                    </div>
                                    <div class="main-menu__call-content">
                                        <span>Phone Number</span>
                                        <p><a href="tel:<?php if(!empty(@$setting_data->phone)): ?> <?php echo e(@$setting_data->phone); ?> <?php else: ?> +9771238798 <?php endif; ?>"><?php if(!empty(@$setting_data->phone)): ?> <?php echo e(@$setting_data->phone); ?> <?php else: ?> +9771238798 <?php endif; ?></a></p>
                                    </div>
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

<?php /**PATH D:\project\srcjob\resources\views/frontend/partials/seo_header.blade.php ENDPATH**/ ?>