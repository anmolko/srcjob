<div class="sideber">
    <div class="sidebar__single sidebar__search">
        <form method="get" id="searchform" action="<?php echo e(route('searchBlog')); ?>" class="sidebar__search-form">
            <input type="search" id="s" name="s"   placeholder="Find Keywords" oninvalid="this.setCustomValidity('Type a keyword')" oninput="this.setCustomValidity('')" required>
            <button type="submit"><i class="icon-search"></i></button>
        </form>
    </div>
    <?php if(!empty($bcategories)): ?>

    <div class="sidebar__single sidebar__category">
        <h3 class="sidebar__title">Blog Categories</h3>
        <ul class="sidebar__category-list list-unstyled">
            <?php $__currentLoopData = @$bcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="sideber__category-left">
                    <a  class="<?php if(Request::url() === url('/blog/categories/'.$bcategory->slug)): ?> active <?php endif; ?>" href="<?php echo e(url('/blog/categories/'.$bcategory->slug)); ?>"><?php echo e(ucwords(@$bcategory->name)); ?></a>
                </div>
                <div class="sideber__category-right">
                    <span class="sideber__category-count"><?php echo e(@$bcategory->blogs->count()); ?></span>
                    <a href="<?php echo e(url('/blog/categories/'.$bcategory->slug)); ?>" class="sideber__category-arrow"><i
                            class="icon-right-arrow1"></i></a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </ul>
    </div>
    <?php endif; ?>
    <?php if(!empty($latestPosts)): ?>

    <div class="sidebar__single sidebar__post">
        <h3 class="sidebar__title">Latest Posts</h3>
        <ul class="sidebar__post-list list-unstyled">
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li>
                <div class="sidebar__post-image">
                    <img src="<?php if(@$latest->image){?><?php echo e(asset('/images/blog/thumb/thumb_'.@$latest->image)); ?><?php }?>" alt="">
                </div>
                <div class="sidebar__post-content">
                    <h3>
                        <a href="<?php echo e(route('blog.single',@$latest->slug)); ?>"><?php echo e(ucwords(@$latest->title)); ?></a>
                        <span class="sidebar__post-content-meta"><i class="icon-clock"></i> <?php echo e(date('j M, Y',strtotime(@$latest->created_at))); ?></span>
                    </h3>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </ul>
    </div>
    <?php endif; ?>
    
</div>

<?php /**PATH D:\project\srcjob\resources\views/frontend/pages/blogs/sidebar.blade.php ENDPATH**/ ?>