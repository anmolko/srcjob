

<div class="sideber">

    <?php if(!empty($slider_lists)): ?>

    <div class="sidebar__single sidebar__category">
        <h3 class="sidebar__title">All Slider Lists</h3>
        <ul class="sidebar__category-list list-unstyled">
            <?php $__currentLoopData = @$slider_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="sideber__category-left">
                    <a  class="<?php if(Request::url() === url('/slider-list/'.$slider->subheading)): ?> active <?php endif; ?>" href="<?php echo e(url('/slider-list/'.$slider->subheading)); ?>"><?php echo e(ucwords(@$slider->list_header)); ?></a>
                </div>
                <div class="sideber__category-right">
                    <a href="<?php echo e(url('/slider-list/'.$slider->subheading)); ?>" class="sideber__category-arrow"><i
                            class="icon-right-arrow1"></i></a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </ul>
    </div>
    <?php endif; ?>

    
</div>

<?php /**PATH D:\project\srcjob\resources\views/frontend/pages/sliderlist/sidebar.blade.php ENDPATH**/ ?>