
<?php $__env->startSection('title'); ?> <?php echo e(ucwords(@$cat_name)); ?> | Blog <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        
        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets/frontend/images/backgrounds/page-header-bg.jpg')); ?>);">
            </div>
            <div class="page-header__shape-one float-bob-x-2"></div>
            <div class="page-header__shape-2 float-bob-y">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-2.png')); ?>" alt="">
            </div>
            <div class="page-header__shape-3 float-bob-x">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-3.png')); ?>" alt="">
            </div>
            <div class="page-header__shape-4 float-bob-y">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-4.png')); ?>" alt="">
            </div>
            <div class="container">
                <div class="page-header__inner text-left">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="/">Home</a></li>
                        <li> <a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
                    </ul>
                    <h2>Category : <?php echo e(ucwords($cat_name)); ?></h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->

    
        <!--Blog Page Start-->
        <div class="blog-page">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="row">
                        <?php if(count($allPosts) > 0): ?>

                            <?php $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--Blog Single Start-->
                                <div class="col-xl-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                                    <div class="blog-three__single">
                                        <div class="blog-three__img">
                                            <img src="<?php if(@$post->image){?><?php echo e(asset('/images/blog/'.@$post->image)); ?><?php }?>" alt="<?php echo e(@$post->slug); ?>">
                                        </div>
                                        <div class="blog-three__content">

                                            <div class="blog-three__date">
                                                <span><?php echo e(date('j',strtotime(@$post->created_at))); ?></span>
                                                <p><?php echo e(date('M',strtotime(@$post->created_at))); ?></p>
                                            </div>
                                            <div class="blog-three__title-box">
                                                <h4 class="blog-three__title"><a href="<?php echo e(route('blog.single',$post->slug)); ?>">
                                                <?php echo ucwords(Str::limit(@$post->title, 45,'...')); ?>

                                                </a></h4>
                                            </div>
                                           
                                            <div class="blog-three__content-box">
                                                <ul class="blog-three__meta list-unstyled">
                                                    <li>
                                                    <a href="<?php echo e(url('/blog/categories/'.@$post->category->slug)); ?>"><i class="icon-tag-chevron-thin"></i><?php echo e(ucwords($post->category->name)); ?></a>

                                                    </li>
                                                    
                                                </ul>
                                                <div class="blog-three__btn-box">
                                                    <a href="<?php echo e(route('blog.single',$post->slug)); ?>">Details<i
                                                            class="icon-fast-forward-thin-double-arrows"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Blog Single end-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="blog-page__pagination">

                                <?php echo e($allPosts->links('vendor.pagination.default')); ?>


                            </div>
                        <?php else: ?>
                                <section class="no-results not-found">
                                        <h2 class="page-title">Nothing Found</h2>
                                    <div class="page-content">
                                        <p>It seems we can not find what you are looking for.</p>
                                    
                                    </div>
                                </section>
                        <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <?php echo $__env->make('frontend.pages.blogs.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    </div>

                </div>
            </div>
        </div>
        <!--Blog Page End-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\srcjob\resources\views/frontend/pages/blogs/category.blade.php ENDPATH**/ ?>