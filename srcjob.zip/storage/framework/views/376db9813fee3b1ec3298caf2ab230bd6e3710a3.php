
<?php $__env->startSection('title'); ?>  <?php echo e(ucwords(@$singleSlider->list_header)); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
           
    .custom-editor .media{
        display: block;
    }

    .custom-editor{
        font-size: 1.1875rem;
    }
    .canosoft-listing ul,.canosoft-listing ol {
        padding: 0;
        margin-left: 15px;
    }
   
	.widget-category ul li a.active {
			color: #fc653c !important;
		}
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets/frontend/images/backgrounds/page-header-bg.jpg')); ?>);">
            </div>
            <div class="page-header__shape-one float-bob-x-2"></div>
            <div class="page-header__shape-2 float-bob-y">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-2.png')); ?>" alt="">
            </div>
            <div class="page-header__shape-3 float-bob-x">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-3.png')); ?>" alt="">
            </div>
            <div class="page-header__shape-4 float-bob-y">
                <img src="<?php echo e(asset('assets/frontend/images/shapes/page-header-shape-4.png')); ?>" alt="">
            </div>
            <div class="container">
                <div class="page-header__inner text-left">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="/">Home</a></li>
                        <li> <a href="<?php echo e(url('/'.@$singleSlider->section->page->slug)); ?>"><?php echo e(ucwords(@$singleSlider->section->page->name)); ?></a></li>
                        <li> <a href="#"><?php echo e(ucwords(@$singleSlider->list_header)); ?></a></li>
                    </ul>
                    <h2><?php echo e(ucwords(@$singleSlider->list_header)); ?></h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->


        <!-- Blog Details Area start -->
           <!--Blog Details Start-->
           <section class="blog-details">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="blog-details__left">
                            <div class="blog-details__inner">
                                <div class="blog-details__single">
                                <div class="blog-list__img-box">
                                        <div class="blog-list__img">
                                            <img src="<?php echo e(asset('/images/section_elements/list_1/'.$singleSlider->list_image)); ?>" alt="<?php echo e(@$singleSlider->list_header); ?>">
                                        </div>
                                    </div>
                                    <div class="blog-list__content">
                                        <h4 class="blog-list__title"><?php echo e(ucwords(@$singleSlider->list_header)); ?></h4>
                                        <?php echo e(@$singleSlider->list_description); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <?php echo $__env->make('frontend.pages.sliderlist.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </section>
        <!--Blog Details End-->


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\srcjob\resources\views/frontend/pages/sliderlist/single.blade.php ENDPATH**/ ?>